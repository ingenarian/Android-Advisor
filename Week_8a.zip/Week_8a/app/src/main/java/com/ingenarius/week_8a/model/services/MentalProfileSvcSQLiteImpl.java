package com.ingenarius.week_8a.model.services;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import com.ingenarius.week_8a.model.domain.MentalProfile;

import java.io.File;

/**
 * Created by ishmael on 10/17/14.
 *
 * Service implementations (run-time) for the IMentalProfileSvc interface specs
 *
 */
public class MentalProfileSvcSQLiteImpl implements IMentalProfileSvc {

    private static final int CURRENT_DATABASE_VERSION = 1;
    private SQLiteDatabase iDatabase;
    private File iDatabaseFile;


    public void createDB(){

        //Autobaun
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/profiles.db");

        //Porsche AG
        iDatabaseFile = dbPath;

        //Porsche 980 engine 5.7 litre 612 hp V10 (street legal, but originally designed for racing.)
        iDatabase = SQLiteDatabase.openOrCreateDatabase(iDatabaseFile.getPath(), null);

        //Porsche Carrera GT
        iDatabase.setVersion(CURRENT_DATABASE_VERSION);

    }// end of createDB

    public void createTable(){

        //Terraforming the MentalProfile class
        MentalProfile ishmael = new MentalProfile();
        ishmael.setProfileName("James Bond");
        String name = ishmael.getProfileName();

        //Terraforming the profiles database
        iDatabase.execSQL("CREATE TABLE neuroengineering (_id INTEGER PRIMARY KEY, data TEXT);");
        iDatabase.execSQL("INSERT INTO neuroengineering (data) VALUES ('" + name + "');");


    }// end of createTable

    public MentalProfile readRecord(MentalProfile profile){

        //Approaching the on-ramp
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/profiles.db");

        //Shifting gears
        iDatabaseFile = dbPath;

        //Accelerating to data source
        iDatabase = SQLiteDatabase.openDatabase(iDatabaseFile.getAbsolutePath(),null,0);

        //Executing a query against table
        Cursor c = iDatabase.rawQuery("SELECT data FROM neuroengineering", null);

        //Position the cursor for data retrieval
        c.moveToFirst();

        //Making a new instance of profile object
        MentalProfile mentalProfile = new MentalProfile();

        //Storing results as a profile object property
        mentalProfile.setProfileName(c.getString(0));

        //Returning updated record to caller
        return mentalProfile;

    }// end of readRecord


    public MentalProfile updateRecord(MentalProfile profile){

        //Approaching the on-ramp
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/profiles.db");

        //Shifting gears
        iDatabaseFile = dbPath;

        //Accelerating to data source
        iDatabase = SQLiteDatabase.openDatabase(iDatabaseFile.getAbsolutePath(),null,0);

        //Change object property, assign ownership, and set aside for attribute container
        MentalProfile thomas = new MentalProfile();
        thomas.setProfileName("James Bond");
        String name = thomas.getProfileName();

        //Creating an attribute container
        ContentValues values = new ContentValues();

        //Adding new attribute data to table
        values.put("data",name);

        //Executing CRUD operation based on service call request
        iDatabase.update("neuroengineering",values,null,null);

        //Executing a query against table
        Cursor c = iDatabase.rawQuery("SELECT data FROM neuroengineering", null);

        //Position the cursor for data retrieval
        c.moveToFirst();

        //Making a new instance of profile object
        MentalProfile mentalProfile = new MentalProfile();

        //Storing results as a profile object property
        mentalProfile.setProfileName(c.getString(0));

        //Returning updated record to caller
        return mentalProfile;

    }// end of updateRecord

    public void deleteRecord(){

        //Get my database path
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/profiles.db");

        //Assign property ownership of the database path
        iDatabaseFile = dbPath;

        //Assign ownership of database operations
        iDatabase = SQLiteDatabase.openDatabase(iDatabaseFile.getAbsolutePath(),null,0);

        //Records be gone
       // iDatabase.delete("neuroengineering","_id",null);

        //*****IMPORTANT OPERATION FOR RESET PURPOSES*******
       // iDatabaseFile.delete();

    }//end of deleteTable

}// end of MentalProfileSvcSQLiteImpl


