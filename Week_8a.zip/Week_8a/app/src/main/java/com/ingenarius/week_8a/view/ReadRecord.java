package com.ingenarius.week_8a.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.ingenarius.week_8a.R;
import com.ingenarius.week_8a.model.Week_8a;
import com.ingenarius.week_8a.model.domain.MentalProfile;
import com.ingenarius.week_8a.model.services.MentalProfileSvcSQLiteImpl;

/**
 * Created by ishmael on 10/17/14.
 *
 * ReadRecord a Use Case Manager in a normal MVC architecture.
 * It calls the service implementation on behalf of the Fragment (Controller)
 *
 */
public class ReadRecord extends ActionBarActivity {

    MentalProfile returnedProfile = new MentalProfile();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_record);

        //  Show the Up button in the action bar.
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Creating an instance of SQLite Implementation for Mental Profiles
        MentalProfileSvcSQLiteImpl profileDB1 = new MentalProfileSvcSQLiteImpl();

        //Calling a read record behavior on behalf of a com.ingenarius.week_8.view
        returnedProfile = profileDB1.readRecord(returnedProfile);

        //Preparing a com.ingenarius.week_8.view to bring focus to a property of a returned object
        final TextView txtData2 = (TextView) findViewById(R.id.txtData2);

        //Giving a com.ingenarius.week_8.view ownership of the property of the return object
        String str2 = returnedProfile.getProfileName();

        // Let the world see
        txtData2.setText(str2.trim());

    }// end of onCreate

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpTo(this, new Intent(this, Week_8a.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }// End of onOptionsItemSelected


}// end of ReadRecord
