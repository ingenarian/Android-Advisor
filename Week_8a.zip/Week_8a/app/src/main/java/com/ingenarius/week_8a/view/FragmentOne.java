package com.ingenarius.week_8a.view;

/**
 * Created by ishmael on 9/27/14.
 */

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ingenarius.week_8a.R;

public class FragmentOne extends Fragment {

    public static Fragment newInstance(Context context) {

        FragmentOne f = new FragmentOne();
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_one, null);

        //Establishing the master controller
        return root;
    }


}

