package com.ingenarius.week_8a.model.services;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import com.ingenarius.week_8a.model.domain.MentalGoal;

import java.io.File;

/**
 * Created by ishmael on 10/17/14.
 *
 * Service implementations (run-time) for the IMentalGoalSvc interface specs
 *
 */
public class MentalGoalSvcSQLiteImpl implements IMentalGoalSvc {

    private static final int CURRENT_DATABASE_VERSION = 1;
    private SQLiteDatabase tDatabase;
    private File tDatabaseFile;


    public void createDB(){

        //Autobaun
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/goals.db");

        //Daimler AG (MBZ)
        tDatabaseFile = dbPath;

        //AMG (MBZ) "65" M275 6.0 L V12 BiTurbo
        tDatabase = SQLiteDatabase.openOrCreateDatabase(tDatabaseFile.getPath(), null);

        //SL65 AMG (MBZ)
        tDatabase.setVersion(CURRENT_DATABASE_VERSION);

    }// end of createDB

    public void createTable(){

        //Terraforming the MentalGoal class
        MentalGoal thomas = new MentalGoal();
        thomas.setGoalName("Mission Impossible");
        String name = thomas.getGoalName();

        //Terraforming the goals database
        tDatabase.execSQL("CREATE TABLE bioengineering (_id INTEGER PRIMARY KEY, data TEXT);");
        tDatabase.execSQL("INSERT INTO bioengineering (data) VALUES ('" + name + "');");


    }// end of createTable

    public MentalGoal readGoal(MentalGoal goal){

        //Approaching the on-ramp
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/goals.db");

        //Shifting gears
        tDatabaseFile = dbPath;

        //Accelerating to data source
        tDatabase = SQLiteDatabase.openDatabase(tDatabaseFile.getAbsolutePath(),null,0);

        //Executing a query against table
        Cursor c = tDatabase.rawQuery("SELECT data FROM bioengineering", null);

        //Position the cursor for data retrieval
        c.moveToFirst();

        //Making a new instance of goal object
        MentalGoal mentalGoal = new MentalGoal();

        //Storing results as a profile object property
        mentalGoal.setGoalName(c.getString(0));

        //Returning updated goal to caller
        return mentalGoal;

    }// end of readGoal


    public MentalGoal updateGoal(MentalGoal goal){

        //Approaching the on-ramp
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/goals.db");

        //Shifting gears
        tDatabaseFile = dbPath;

        //Accelerating to data source
        tDatabase = SQLiteDatabase.openDatabase(tDatabaseFile.getAbsolutePath(),null,0);

        //Change object property, assign ownership, and set aside for attribute container
        MentalGoal lateef = new MentalGoal();
        lateef.setGoalName("Spartan");
        String name = lateef.getGoalName();

        //Creating an attribute container
        ContentValues values = new ContentValues();

        //Adding new attribute data to table
        values.put("data",name);

        //Executing CRUD operation based on service call request
        tDatabase.update("bioengineering",values,null,null);

        //Executing a query against table
        Cursor c = tDatabase.rawQuery("SELECT data FROM bioengineering", null);

        //Position the cursor for data retrieval
        c.moveToFirst();

        //Making a new instance of goal object
        MentalGoal mentalGoal = new MentalGoal();

        //Storing results as a goal object property
        mentalGoal.setGoalName(c.getString(0));

        //Returning updated record to caller
        return mentalGoal;

    }// end of updateGoal

    public void deleteGoal(){

        //Get my database path
        File dbPath = new File(Environment.getExternalStorageDirectory().getPath() +"/goals.db");

        //Assign property ownership of the database path
        tDatabaseFile = dbPath;

        //Assign ownership of database operations
        tDatabase = SQLiteDatabase.openDatabase(tDatabaseFile.getAbsolutePath(),null,0);

        //Records be gone
       // tDatabase.delete("bioengineering","_id",null);

        //*****IMPORTANT OPERATION FOR RESET PURPOSES*******
        // tDatabaseFile.delete();

    }//end of deleteTable

}// end of MentalGoalSvcSQLiteImpl