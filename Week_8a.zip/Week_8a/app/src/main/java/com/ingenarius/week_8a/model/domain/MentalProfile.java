package com.ingenarius.week_8a.model.domain;

/**
 * Created by ishmael on 10/1/14.\
 *
 * Represents the Conceptual Domain (Problem Domain)
 *
 * Value object spec.
 */

public class MentalProfile{

    private String profileName;

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getProfileName() {
        return profileName;
    }


} // end of MentalProfile