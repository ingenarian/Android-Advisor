package com.ingenarius.week_8a.view;

/**
 * Created by ishmael on 9/27/14.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ingenarius.week_8a.R;

public class FragmentTwo extends Fragment {


    public static Fragment newInstance(Context context) {
        FragmentTwo f = new FragmentTwo();
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_two, null);

        //Create a button to launch the CreateRecord Activity & ActionBar for a Profile
        Button button1 = (Button) root.findViewById(R.id.buttonView1);

        button1.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                newRecord();

            }// end of onClick
        });// end of setOnClickListener

        //Create a button to launch the CreateGoal Activity & ActionBar for a Profile
        Button button2 = (Button) root.findViewById(R.id.buttonView2);

        button2.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                newGoal();

            }// end of onClick
        });// end of setOnClickListener


        return root;
    }

    private void newRecord(){

        // Transfer control to the create record
        Intent in = new Intent(getActivity(),CreateRecord.class);
        startActivity(in);

    }// end of newRecord

    private void newGoal(){

        // Transfer control to the create goal
        Intent in = new Intent(getActivity(),CreateGoal.class);
        startActivity(in);

    }// end of newGoal

}// end of FragmentTwo



