package com.ingenarius.week_8a.model.services;

import com.ingenarius.week_8a.model.domain.MentalProfile;

/**
 * Created by ishmael on 10/17/14.
 *
 * This goes outside MVC best practices but that MVC
 * best practices in an Android environment is evolving.
 *
 * Each of these interfaces should be individual specs (generalizations)
 * supporting individual implementations (realizations).
 *
 *
 *
 */
public interface IMentalProfileSvc {

    //Interface specifications for CRUD operations
    public void createDB();
    public void createTable();
    public MentalProfile readRecord(MentalProfile profile);
    public MentalProfile updateRecord(MentalProfile profile);
    public void deleteRecord();

}// end of IMentalProfileSvc
