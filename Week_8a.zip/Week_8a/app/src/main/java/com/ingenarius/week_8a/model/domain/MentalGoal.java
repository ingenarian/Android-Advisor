package com.ingenarius.week_8a.model.domain;

/**
 * Created by ishmael on 10/1/14.\
 *
 * Represents the Conceptual Domain (Problem Domain)
 *
 * Value object spec.
 */
public class MentalGoal {

    private String goalName;

    public void setGoalName(String goalName) {
        this.goalName = goalName;
    }

    public String getGoalName() {
        return goalName;
    }


}// end of Mental Goal
