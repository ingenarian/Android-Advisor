package com.ingenarius.week_8a.view;

/**
 * Created by ishmael on 9/27/14.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ingenarius.week_8a.R;

public class FragmentThree extends Fragment {
    public static Fragment newInstance(Context context) {
        FragmentThree f = new FragmentThree();
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_three, null);

        //Create a button to launch the ReadRecord Activity & ActionBar for a Profile
        Button button1 = (Button) root.findViewById(R.id.buttonView1);

        button1.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                viewRecord();

            }// end of onClick
        });// end of setOnClickListener


        //Create a button to launch the ReadRecord Activity & ActionBar for a Profile
        Button button2 = (Button) root.findViewById(R.id.buttonView2);

        button2.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                viewGoal();

            }// end of onClick
        });// end of setOnClickListener

        return root;
    } // end of onCreateView

    private void viewRecord(){

        // Transfer control to the read record
        Intent in = new Intent(getActivity(),ReadRecord.class);
        startActivity(in);

    }// end of viewRecord

    private void viewGoal(){

        // Transfer control to the read record
        Intent in = new Intent(getActivity(),ReadGoal.class);
        startActivity(in);

    }// end of viewGoal

} // end of FragmentThree
