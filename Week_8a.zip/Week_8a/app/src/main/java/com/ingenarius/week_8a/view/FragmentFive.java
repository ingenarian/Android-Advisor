package com.ingenarius.week_8a.view;

/**
 * Created by ishmael on 10/8/14.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ingenarius.week_8a.R;

public class FragmentFive extends Fragment {

    public static FragmentFive newInstance(Context context) {
        FragmentFive f = new FragmentFive();
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_five, null);

        //Create a button to launch the DeleteRecord Activity & ActionBar for a Profile
        Button button1 = (Button) root.findViewById(R.id.buttonView1);

        button1.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                destroyRecord();

            }// end of onClick
        });// end of setOnClickListener

        //Create a button to launch the DeleteGoal Activity & ActionBar for a Goal
        Button button2 = (Button) root.findViewById(R.id.buttonView2);

        button2.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                destroyGoal();

            }// end of onClick
        });// end of setOnClickListener


        return root;

    }// end of OnCreateView

    private void destroyRecord(){

        //Transfer control to the DeleteRecord
        Intent in = new Intent(getActivity(),DeleteRecord.class);
        startActivity(in);

    }// end of destroyRecord


    private void destroyGoal(){

        //Transfer control to the DeleteGoal
        Intent in = new Intent(getActivity(),DeleteGoal.class);
        startActivity(in);

    }// end of destroyGoal

}// end of FragmentFive
