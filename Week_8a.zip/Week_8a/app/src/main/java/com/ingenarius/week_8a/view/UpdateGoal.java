package com.ingenarius.week_8a.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.ingenarius.week_8a.R;
import com.ingenarius.week_8a.model.Week_8a;
import com.ingenarius.week_8a.model.domain.MentalGoal;
import com.ingenarius.week_8a.model.services.MentalGoalSvcSQLiteImpl;
/**
 * Created by ishmael on 10/17/14.
 *
 * UpdateGoal a Use Case Manager in a normal MVC architecture.
 * It calls the service implementation on behalf of the Fragment (Controller)
 *
 */
public class UpdateGoal extends ActionBarActivity {

    MentalGoal returnedGoal = new MentalGoal();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_goal);

        //  Show the Up button in the action bar.
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Creating an instance of SQLite Implementation for Mental Goals
        MentalGoalSvcSQLiteImpl goalDB1 = new MentalGoalSvcSQLiteImpl();

        //Calling a update record behavior on behalf of a view
        returnedGoal = goalDB1.updateGoal(returnedGoal);

        //Giving a view ownership of the property of the return object
        String str12 = returnedGoal.getGoalName();

        // Create a Text Views
        final TextView txtData12 = (TextView) findViewById(R.id.txtData12);

        //Display Text (Use case realization)
        txtData12.setText(str12.trim());

    }// end of onCreate

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpTo(this, new Intent(this, Week_8a.class));
            return true;
        }
        return super.onOptionsItemSelected(item);

    }// End of onOptionsItemSelected


}// end of UpdateGoal

