package com.ingenarius.week_8a.view;

/**
 * Created by ishmael on 9/28/14.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ingenarius.week_8a.R;

public class FragmentFour extends Fragment {

    public static Fragment newInstance(Context context) {
        FragmentFour f = new FragmentFour();
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_four, null);

        //Create a button to launch the UpdateRecord Activity & ActionBar for a Profile
        Button button1 = (Button) root.findViewById(R.id.buttonView1);

        button1.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                modifyRecord();

            }// end of onClick
        });// end of setOnClickListener


        //Create a button to launch the UpdateGoal Activity & ActionBar for a Goal
        Button button2 = (Button) root.findViewById(R.id.buttonView2);

        button2.setOnClickListener(new View.OnClickListener()  {

            public void onClick(View view){

                // Calling a controller operation
                modifyGoal();

            }// end of onClick
        });// end of setOnClickListener

        return root;
    }// end of onCreateView

    private void modifyRecord(){

        // Transfer control to the Update Record
        Intent in = new Intent(getActivity(),UpdateRecord.class);
        startActivity(in);

    }// end of modifyRecord

    private void modifyGoal(){

        // Transfer control to the Update Goal
        Intent in = new Intent(getActivity(),UpdateGoal.class);
        startActivity(in);

    }// end of modifyGoal

}// end of FragmentFour